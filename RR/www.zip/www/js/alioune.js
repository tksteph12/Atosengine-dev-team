        


        //Point d'entrée de l'application
$(document).ready(function() {
	getVars();
 });
